package ru.geekbrains.java1.dz.dz1.GorilenkoAndrey;

public class Zadanie2 {
    public static void main(String[] args) {
        int I=1;
        byte b=127;
        short sh=-32768;
        long l=111111111L;
        float myTemp=97.9F;
        char c='C';
        double d=123.123;
        boolean b1=true;

    }
}
