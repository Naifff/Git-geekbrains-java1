package ru.geekbrains.java1.dz.dz1.GorilenkoAndrey;

public class Zadanie7 {
    public static void main(String[] args) {
String a="Ivanov Ivan";
    String c=getName(a);
    System.out.println(c);

    }
public static String getName(String b){
String c="ПРивет, " +b;
return c;
    }


}
