package ru.geekbrains.java1.dz.dz6.AndreyMelchuk;

public interface RoboCatInterface {
    String AnimalKind = "RoboCat";
    boolean run(float value);
    boolean jump(float value);
    boolean swim(float value);
    void animalInfo();
    void totalInfoLocal ();
}
