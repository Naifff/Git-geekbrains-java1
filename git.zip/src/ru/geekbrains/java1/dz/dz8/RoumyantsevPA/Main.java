package ru.geekbrains.java1.dz.dz8.RoumyantsevPA;

public class Main {

    public static void main(String[] args) {
        Window myWindow =new Window();
    }
}
