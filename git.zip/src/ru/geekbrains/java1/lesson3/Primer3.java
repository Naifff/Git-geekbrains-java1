package ru.geekbrains.java1.lesson3;

/**
 * Created by i on 19.10.2017.
 */
public class Primer3 {
    public static void main(String[] args) {
        System.out.printf("string: %s  number %d char  %c , %.2f", "ttt", 10, 'a', 3.5d);

    }
}
