package ru.geekbrains.java1.lesson3;

import java.util.Random;

/**
 * Created by i on 19.10.2017.
 */
public class Primer2 {
    public static void main(String[] args) {
        Random random = new Random();
        int a = random.nextInt(50);
        System.out.println(a);
    }
}
