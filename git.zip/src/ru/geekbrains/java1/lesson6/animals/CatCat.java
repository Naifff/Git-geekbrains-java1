package ru.geekbrains.java1.lesson6.animals;

/**
 * Created by Home-pc on 01.08.2016.
 */
public class CatCat extends Cat {
    public CatCat(String name, String color, float weight) {
        super(name, color, weight);
    }

//    @Override
//    public void voice() {
//        System.out.println(name + " мяукает и орет");
//    }
}
