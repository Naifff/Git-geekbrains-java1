package ru.geekbrains.java1.lesson8;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ActionComBox implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("!!!@@###");
    }
}
