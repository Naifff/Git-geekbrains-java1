package ru.geekbrains.java1.lesson8;


public class Main {
    public static void main(String[] args) {
        Win win = new Win();

    }
}
