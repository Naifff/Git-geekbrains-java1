package ru.geekbrains.java1.lesson8;


public class MainClass {
    public static void main(String[] args) {
        Form1 w = new Form1();
    }

}
