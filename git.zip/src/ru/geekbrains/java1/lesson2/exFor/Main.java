package ru.geekbrains.java1.lesson2.exFor;

public class Main {
    public static void main(String[] args) {

//        int h = 7;
//
//        for (int i = 0; i < 3; i++) {
//            System.out.println("i: " + i);
//            int b =10;
//
//            if (b == 0) {
//                b =3;
//            }
//        }
//int c = b +h + i;

//        System.out.println("---------------------------");
//        for (int i = 10; i > 2; i -= 2) { // i = i - 2;
//            System.out.println("i: " + i);
//        }
//        System.out.println("---------------------------");
//        for (int i = 0; i < 8; i++) {
//            if (i == 4) break;
//            System.out.println("i: " + i);
//        }
//        for (int i = 0; i < 8; i++) {
//            if (i == 4) continue;
//            System.out.println("i: " + i);
//        }
//        System.out.println("---------------------------");
//        int[] a = new int[5];
//        for (int i = 0; i < 5; i++) {
//            a[i] = i * 3;
//            System.out.print(a[i] + " ");
//        }
//        System.out.println();
//        System.out.println("---------------------------");
//        int b[] = {1, 6, 3, 1, 1};
//        for (int i = 0; i < b.length; i++) {
//            if(b[i] < 4)
//                b[i] *= 2;
//            else
//                b[i] *= 3;
//            System.out.print(b[i] + " ");
//        }
//        System.out.println();
//        System.out.println("---------------------------");
//        for (int i = 0; i < 3; i++) {
//            for (int j = 0; j < 3; j++) {
//                System.out.println("i: " + i + " j: " + j);
//            }
//        }

//        System.out.println("---------------------------");
//         печатаем таблицу 3х3, стостоящую из *
//        for (int i = 0; i < 3; i++) { // отвечает за перевод строк
//            for (int j = 0; j < 3; j++) { // отвечает за печать строки
//                System.out.print("* "); // печатаем * и пробел
//            }
//            System.out.println(); // переводим строку
//        }
    }
}
