package ru.geekbrains.java1.lesson2.exFor;

/**
 * Created by Home-pc on 21.07.2016.
 */
public class MainWhile {
    public static void main(String[] args) {
        // Неопределенные циклы
        int r = 1; // Тестовая переменная
//        while (r < 10) { // выполняем цикл до тех пор, пока r < 10
//            r++;
//            System.out.println(r);
//        }
        r = 20;
//        while (true) { // Бесконечный цикл, без внутреннего оператора break цикл никогда не закончится
//            r++;
//            if (r > 40) {
//                System.out.println("stop");
//                break; // При r больше 40 выходим из бесконечного цикла
//            }
//            System.out.print(r + " ");
//        }
//
        for (;;){

        }
    }
}
