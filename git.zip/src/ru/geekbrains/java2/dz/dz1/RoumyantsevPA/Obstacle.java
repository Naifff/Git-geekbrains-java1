package ru.geekbrains.java2.dz.dz1.RoumyantsevPA;

public abstract class Obstacle {
    public abstract void doIt(Competitor c);
}
