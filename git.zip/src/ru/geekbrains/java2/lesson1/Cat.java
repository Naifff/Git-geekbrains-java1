package ru.geekbrains.java2.lesson1;

public class Cat extends Animal {
    public Cat(String name) {
        super("Cat", name, 500, 50, 0);
    }
}
