package ru.geekbrains.java2.lesson1;

public class test {
}
