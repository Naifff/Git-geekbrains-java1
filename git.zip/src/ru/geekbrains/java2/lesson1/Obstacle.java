package ru.geekbrains.java2.lesson1;

public abstract class Obstacle {
    public abstract void doIt(Competitor c);
}
