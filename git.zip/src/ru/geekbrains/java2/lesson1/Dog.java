package ru.geekbrains.java2.lesson1;

public class Dog extends Animal {
    public Dog(String name) {
        super("Dog", name, 1000, 10, 10);
    }
}
