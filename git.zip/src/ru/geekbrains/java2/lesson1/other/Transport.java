package ru.geekbrains.racing.other;

public interface Transport {
    void start(AnotherHuman ah);
    void end(AnotherHuman ah);
}
